<?php

return [
    'name'    => 'Webkul Bagisto Admin',
    'version' => '0.0.1',
];
