<?php

namespace Webkul\Attribute\Models;

use Konekt\Concord\Proxies\ModelProxy;

class AttributeOptionProxy extends ModelProxy
{

}