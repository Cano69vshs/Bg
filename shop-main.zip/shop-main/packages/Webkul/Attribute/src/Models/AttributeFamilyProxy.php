<?php

namespace Webkul\Attribute\Models;

use Konekt\Concord\Proxies\ModelProxy;

class AttributeFamilyProxy extends ModelProxy
{

}